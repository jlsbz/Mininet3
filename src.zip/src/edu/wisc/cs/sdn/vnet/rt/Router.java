package edu.wisc.cs.sdn.vnet.rt;

import java.util.*;
import java.nio.ByteBuffer;

import edu.wisc.cs.sdn.vnet.Device;
import edu.wisc.cs.sdn.vnet.DumpFile;
import edu.wisc.cs.sdn.vnet.Iface;
import net.floodlightcontroller.packet.*;


/**
 * @author Aaron Gember-Jacobson and Anubhavnidhi Abhashkumar
 */
public class Router extends Device
{	
	/** Routing table for the router */
	private RouteTable routeTable;
	
	/** ARP cache for the router */
	private ArpCache arpCache;
	
	/**
	 * Creates a router for a specific host.
	 * @param host hostname for the router
	 */
	public Router(String host, DumpFile logfile)
	{
		super(host,logfile);
		this.routeTable = new RouteTable();
		this.arpCache = new ArpCache();
	}
	
	/**
	 * @return routing table for the router
	 */
	public RouteTable getRouteTable()
	{ return this.routeTable; }
	
	/** Used for ARP request */
	private Timer scheduler = new Timer();
	
	class InterfacePair
	{
	  public Iface inIface;
	  public Iface outIface;
	  
	  public InterfacePair(Iface inIface, Iface outIface)
	  {
	    this.inIface = inIface;
	    this.outIface = outIface;
    }
  }
	
	private final static int RipIp = IPv4.toIPv4Address("224.0.0.9");
	final Set<Integer> arpAttempt = Collections.synchronizedSet(new HashSet<Integer>());
	final Map<Integer, List<Ethernet>> packetQueue = Collections.synchronizedMap(new HashMap<Integer, List<Ethernet>>());
	final Map<Ethernet, InterfacePair> packetInterfaceMap = Collections.synchronizedMap(new HashMap<Ethernet, InterfacePair>());
	
	/**
	 * Load a new routing table from a file.
	 * @param routeTableFile the name of the file containing the routing table
	 */
	public void loadRouteTable(String routeTableFile)
	{
		if (!routeTable.load(routeTableFile, this))
		{
			System.err.println("Error setting up routing table from file "
					+ routeTableFile);
			System.exit(1);
		}
		
		System.out.println("Loaded static route table");
		System.out.println("-------------------------------------------------");
		System.out.print(this.routeTable.toString());
		System.out.println("-------------------------------------------------");
	}
	
	/**
	 * Load a new ARP cache from a file.
	 * @param arpCacheFile the name of the file containing the ARP cache
	 */
	public void loadArpCache(String arpCacheFile)
	{
		if (!arpCache.load(arpCacheFile))
		{
			System.err.println("Error setting up ARP cache from file "
					+ arpCacheFile);
			System.exit(1);
		}
		
		System.out.println("Loaded static ARP cache");
		System.out.println("----------------------------------");
		System.out.print(this.arpCache.toString());
		System.out.println("----------------------------------");
	}

  /** run RIP */
  public void runRIP()
  {
    for (Iface iface : interfaces.values())
    {
      int ip = iface.getIpAddress();
      int mask = iface.getSubnetMask();
      routeTable.insert(ip & mask, 0, mask, iface, 1, false);
    }
    
    System.out.println("Initial route table : \n" + routeTable.toString());
    
    for (Iface iface : interfaces.values())
    { sendRIP(iface, true, false, null); }
    
    scheduler.schedule(new RipFresh(), 0, 10 * 1000);
  }
  
	/**
	 * Handle an Ethernet packet received on a specific interface.
	 * @param etherPacket the Ethernet packet that was received
	 * @param inIface the interface on which the packet was received
	 */
	public void handlePacket(Ethernet etherPacket, Iface inIface)
	{

		
		/********************************************************************/
		/* TODO: Handle packets                                             */
		
		switch(etherPacket.getEtherType())
		{
		  case Ethernet.TYPE_IPv4:
			  System.out.println("*** -> Received packet: " +
                etherPacket.toString().replace("\n", "\n\t"));
			  this.handleIpPacket(etherPacket, inIface);
			  break;
		  case Ethernet.TYPE_ARP:
			  System.out.println("*** -> Received packet: " +
                etherPacket.toString().replace("\n", "\n\t"));
        this.handleArpPacket(etherPacket, inIface);
        break;
      default:
        break;
		}
		
		/********************************************************************/
	}
	
	private void handleRipPacket(Ethernet etherPacket, Iface inIface)
	{
	  IPv4 ipPacket = (IPv4) etherPacket.getPayload();
	  UDP udpPacket = (UDP) ipPacket.getPayload();
	  RIPv2 rip = (RIPv2) udpPacket.getPayload();
	  
    // Verify checksum
    short origCksum = udpPacket.getChecksum();
    udpPacket.resetChecksum();
    byte[] serialized = udpPacket.serialize();
    udpPacket.deserialize(serialized, 0, serialized.length);
    short calcCksum = udpPacket.getChecksum();
    if (origCksum != calcCksum)
	  {
      System.out.println("handleRipPacket : udp checksum failed"); 
      return; 
    }  
    
    for (RIPv2Entry ripEntry : rip.getEntries())
    {
      int destIp = ripEntry.getAddress();
      int nextHop = ripEntry.getNextHopAddress();
      int mask = ripEntry.getSubnetMask();
      int metric = ripEntry.getMetric();
     
      if ((destIp & mask) != (inIface.getIpAddress() & inIface.getSubnetMask()) )
      {
        RouteEntry destEntry = routeTable.lookup(destIp);
        RouteEntry nextEntry = routeTable.lookup(nextHop);
        if (destEntry == null)
        { routeTable.insert(destIp, nextHop, mask, inIface, nextEntry.getMetric() + metric, true); }
        else if (nextEntry.getMetric() + metric <= destEntry.getMetric())
        { routeTable.update(destIp, mask, nextHop, inIface, nextEntry.getMetric() + metric); }
      }
    }
    
    System.out.println("New route Table : \n" + routeTable.toString());
    if (rip.getCommand() == RIPv2.COMMAND_REQUEST)
    { sendRIP(inIface, false, true, etherPacket); }
	}
	
	private boolean isRipPacket(Ethernet etherPacket)
	{
	  IPv4 ipPacket = (IPv4) etherPacket.getPayload();
	  if (ipPacket.getProtocol() != IPv4.PROTOCOL_UDP)
	  { return false; }
	  UDP udpPacket = (UDP) ipPacket.getPayload();
	  if (udpPacket.getDestinationPort() != UDP.RIP_PORT)
	  { return false; }
	  return true;
	}
	
	private void handleIpPacket(Ethernet etherPacket, Iface inIface)
	{
		// Make sure it's an IP packet
		if (etherPacket.getEtherType() != Ethernet.TYPE_IPv4)
		{ return; }
		
		// Get IP header
		IPv4 ipPacket = (IPv4)etherPacket.getPayload();
    System.out.println("Handle IP packet");

    // Verify checksum
    short origCksum = ipPacket.getChecksum();
    ipPacket.resetChecksum();
    byte[] serialized = ipPacket.serialize();
    ipPacket.deserialize(serialized, 0, serialized.length);
    short calcCksum = ipPacket.getChecksum();
    if (origCksum != calcCksum)
    {
      System.out.println("handleIpPacket : checksum failed"); 
      return; 
    }  
    
    // Check TTL
    ipPacket.setTtl((byte)(ipPacket.getTtl()-1));
    if (0 == ipPacket.getTtl())
    { 
      System.out.println("handleIpPacket : TTL failed");
      sendICMP(ipPacket, inIface, 11, 0);
      return; 
    }
    
    // Reset checksum now that TTL is decremented
    ipPacket.resetChecksum();
    
    if (isRipPacket(etherPacket))
    {
      handleRipPacket(etherPacket, inIface);
      return;
    }
    
    // Check if packet is destined for one of router's interfaces
    for (Iface iface : this.interfaces.values())
    {
    	if (ipPacket.getDestinationAddress() == iface.getIpAddress())
    	{
    	  switch (ipPacket.getProtocol())
    	  {
    	    case IPv4.PROTOCOL_UDP :
    	    case IPv4.PROTOCOL_TCP :
    	      System.out.println("handleIpPacket : destination port unreachable");
    	      sendICMP(ipPacket, inIface, 3, 3);
    	      return;
    	    case IPv4.PROTOCOL_ICMP :
    	      if (((ICMP) ipPacket.getPayload()).getIcmpType() != 8)
    	      { return; }
    	      sendICMP(ipPacket, inIface, 0, 0);
    	    break;
    	  } 
    	  return;
    	}
    }

    // Do route lookup and forward
    this.forwardIpPacket(etherPacket, inIface);
	}
	
	private void handleArpPacket(Ethernet etherPacket, Iface inIface)
	{
	  ARP arpPacket = (ARP) etherPacket.getPayload();
	  
	  switch (arpPacket.getOpCode())
	  {
	    case ARP.OP_REQUEST:
	      int targetIp = ByteBuffer.wrap(arpPacket.getTargetProtocolAddress()).getInt();
	      if (targetIp != inIface.getIpAddress())
	      { 
	        System.out.println("handleARPPacket : not match");
	        return;
        }
	      sendARP(etherPacket, inIface, targetIp, false);
	      return;
	    case ARP.OP_REPLY:
	      int senderIp = ByteBuffer.wrap(arpPacket.getSenderProtocolAddress()).getInt();
	      MACAddress senderMAC = MACAddress.valueOf(arpPacket.getSenderHardwareAddress());
	      this.arpCache.insert(senderMAC, senderIp);
	      
	      synchronized (packetQueue)
	      {
	        arpAttempt.remove(senderIp);
	        List<Ethernet> ipPacketQueue = packetQueue.get(senderIp);
	        packetQueue.remove(senderIp);
	        if (ipPacketQueue != null)
	        {
	          for (Ethernet packet : ipPacketQueue)
	          {
	            Iface outIface = packetInterfaceMap.get(packet).outIface;
	            packet.setDestinationMACAddress(senderMAC.toBytes());
	            sendPacket(packet, outIface);
	            packetInterfaceMap.remove(packet);
            }
          }
        }
	      return;
	    default:
	      return;
    }
	}
	
	private void sendARP(Ethernet etherPacket, Iface inIface, int targetIp, boolean request)
  {
    System.out.printf("Sending ARP... %s\n", request ? "request" : "reply");
    Ethernet ether = new Ethernet();
    ARP arp = new ARP();
    ether.setPayload(arp);
    
    // set Ethernet header
    ether.setEtherType(Ethernet.TYPE_ARP);
    ether.setSourceMACAddress(inIface.getMacAddress().toBytes());
    ether.setDestinationMACAddress(request ? MACAddress.valueOf("FF:FF:FF:FF:FF:FF").toBytes() : etherPacket.getSourceMACAddress());
    
    // set ARP header
    arp.setHardwareType(ARP.HW_TYPE_ETHERNET);
    arp.setProtocolType(ARP.PROTO_TYPE_IP);
    arp.setHardwareAddressLength((byte) Ethernet.DATALAYER_ADDRESS_LENGTH);
    arp.setProtocolAddressLength((byte) 4);
    arp.setOpCode(request ? ARP.OP_REQUEST : ARP.OP_REPLY);
    arp.setSenderHardwareAddress(inIface.getMacAddress().toBytes());
    arp.setSenderProtocolAddress(inIface.getIpAddress());
    arp.setTargetHardwareAddress(request ? MACAddress.valueOf(0).toBytes() : etherPacket.getSourceMACAddress());
    arp.setTargetProtocolAddress(targetIp);
    
    this.sendPacket(ether, inIface);
  }
  	
  private void sendICMP(IPv4 ipPacket, Iface inIface, int type, int code)
  {
    boolean echo = type == 0 && code == 0;
    Ethernet ether = new Ethernet();
    IPv4 ip = new IPv4();
    ICMP icmp = new ICMP();
    Data data = new Data();
    ether.setPayload(ip);
    ip.setPayload(icmp);
    icmp.setPayload(data);
    
    // prepare
    int destIp = ipPacket.getSourceAddress();
    RouteEntry bestMatch = this.routeTable.lookup(destIp);
    int nextHop = bestMatch.getGatewayAddress();
    if (0 == nextHop)
    { nextHop = destIp; }
    ArpEntry arpEntry = this.arpCache.lookup(nextHop);
    if (null == arpEntry)
    {
      System.out.println("sendICMP : arp not found"); 
      return;
    }
    
    // set Ethernet header
    ether.setEtherType(Ethernet.TYPE_IPv4);
    ether.setSourceMACAddress(inIface.getMacAddress().toBytes());
    ether.setDestinationMACAddress(arpEntry.getMac().toBytes());
    
    // set IP header
    ip.setTtl((byte) 64);
    ip.setProtocol(IPv4.PROTOCOL_ICMP);
    ip.setSourceAddress(echo ? ipPacket.getDestinationAddress() : inIface.getIpAddress());
    ip.setDestinationAddress(destIp);
    
    // set ICMP header
    icmp.setIcmpType((byte) type);
    icmp.setIcmpCode((byte) code);
    
    // set ICMP payload
    if (echo)
      data.setData(ipPacket.getPayload().getPayload().serialize());
    else
    {
      byte[] dataSerial = new byte[4 + ipPacket.getHeaderLength() * 4 + 8];
      ByteBuffer byteBuffer = ByteBuffer.wrap(dataSerial);
      byteBuffer.putInt(0);
      byteBuffer.put(Arrays.copyOfRange(ipPacket.serialize(), 0, ipPacket.getHeaderLength() * 4 + 8));
      byteBuffer.rewind();
      data.setData(dataSerial); 
    }
    
    this.sendPacket(ether, bestMatch.getInterface());
  }
  
  private void sendRIP(Iface outIface, boolean request, boolean response, Ethernet etherPacket)
  {
    Ethernet ether = new Ethernet();
    IPv4 ip = new IPv4();
    UDP udp = new UDP();
    RIPv2 rip = new RIPv2();
    ether.setPayload(ip);
    ip.setPayload(udp);
    udp.setPayload(rip);
    
    // set Ethernet header
    ether.setEtherType(Ethernet.TYPE_IPv4);
    ether.setSourceMACAddress(outIface.getMacAddress().toBytes());
    ether.setDestinationMACAddress(!response ? MACAddress.valueOf("FF:FF:FF:FF:FF:FF").toBytes() : etherPacket.getSourceMACAddress());
    
    // set IP header
    ip.setProtocol(IPv4.PROTOCOL_UDP);
    ip.setTtl((byte) 64);
    ip.setSourceAddress(outIface.getIpAddress());
    ip.setDestinationAddress(!response ? RipIp : ((IPv4) etherPacket.getPayload()).getSourceAddress());
    
    // set UDP header
    udp.setSourcePort(UDP.RIP_PORT);
    udp.setDestinationPort(UDP.RIP_PORT);
    
    // set RIP header
    rip.setCommand(!request ? RIPv2.COMMAND_RESPONSE : RIPv2.COMMAND_REQUEST);
    for (RouteEntry routeEntry : routeTable.getEntries())
    {
      RIPv2Entry ripEntry = new RIPv2Entry(routeEntry.getDestinationAddress(), routeEntry.getMaskAddress(), routeEntry.getMetric());
      ripEntry.setNextHopAddress(outIface.getIpAddress());
      rip.addEntry(ripEntry);
    }
    
    sendPacket(ether, outIface);
  }
  
  private void forwardIpPacket(Ethernet etherPacket, Iface inIface)
  {
    // Make sure it's an IP packet
		if (etherPacket.getEtherType() != Ethernet.TYPE_IPv4)
		{ return; }
    System.out.println("Forward IP packet");
		
		// Get IP header
		IPv4 ipPacket = (IPv4)etherPacket.getPayload();
    int dstAddr = ipPacket.getDestinationAddress();

    // Find matching route table entry 
    RouteEntry bestMatch = this.routeTable.lookup(dstAddr);

    // If no entry matched, do nothing
    if (null == bestMatch)
    {
      System.out.println("handleIpPacket : destination net unreachable");
      sendICMP(ipPacket, inIface, 3, 0); 
      return; 
    }

    // Make sure we don't sent a packet back out the interface it came in
    Iface outIface = bestMatch.getInterface();
    if (outIface == inIface)
    { return; }

    // Set source MAC address in Ethernet header
    etherPacket.setSourceMACAddress(outIface.getMacAddress().toBytes());

    // If no gateway, then nextHop is IP destination
    int nextHop = bestMatch.getGatewayAddress();
    if (0 == nextHop)
    { nextHop = dstAddr; }

    // Set destination MAC address in Ethernet header
    ArpEntry arpEntry = this.arpCache.lookup(nextHop);
    if (null == arpEntry)
    {
      waitForArp(etherPacket, inIface, outIface);
      return; 
    }
    etherPacket.setDestinationMACAddress(arpEntry.getMac().toBytes());
    
    this.sendPacket(etherPacket, outIface);
  }
  
  private void waitForArp(Ethernet etherPacket, Iface inIface, Iface outIface)
  {
    IPv4 ipPacket = (IPv4) etherPacket.getPayload();
    RouteEntry bestMatch = routeTable.lookup(ipPacket.getDestinationAddress());
    int nextHop = bestMatch.getGatewayAddress();
    if (0 == nextHop)
    { nextHop = ipPacket.getDestinationAddress(); }
    
    synchronized (packetQueue)
    {
      if (!packetQueue.containsKey(nextHop))
      { packetQueue.put(nextHop, new ArrayList<Ethernet>()); }
      List<Ethernet> ipPacketQueue = packetQueue.get(nextHop);
      ipPacketQueue.add(etherPacket);
      
      packetInterfaceMap.put(etherPacket, new InterfacePair(inIface, outIface));      
      
      if (!arpAttempt.contains(nextHop))
      { scheduler.schedule(new ArpTimer(etherPacket, nextHop), 0, 1000); }
    }
  }
  
  class ArpTimer extends TimerTask
  {
    Ethernet etherPacket;
    int numAttempts = 3;
    final int ip;
    
    public ArpTimer(Ethernet etherPacket, int ip)
    {
      this.etherPacket = etherPacket;
      this.ip = ip;
    }
    
    @Override
    public void run()
    {
      ArpEntry arpEntry = arpCache.lookup(ip);
      if (arpEntry != null)
      {
        cancel();
        return;
      }
      else
      {
        if (numAttempts == 0)
        {
          synchronized (packetQueue)
          {
            arpAttempt.remove(ip);
            List<Ethernet> ipPacketQueue = packetQueue.get(ip);
            packetQueue.remove(ip);
            if (ipPacketQueue != null)
            {
              for (Ethernet packet : ipPacketQueue)
              {
                System.out.println("Arp Requst timeout : destination host unreachable");
                sendICMP((IPv4) packet.getPayload(), packetInterfaceMap.get(packet).inIface, 3, 1);
              }
            }
          }
          cancel();
        }
        else
        { sendARP(this.etherPacket, packetInterfaceMap.get(this.etherPacket).outIface, ip, true); }
      }
      numAttempts--;
    }
  }
  
  class RipFresh extends TimerTask
  {
    @Override
    public void run()
    {
      for (Iface iface : interfaces.values())
      { sendRIP(iface, false, false, null); }
    }
  }
}
