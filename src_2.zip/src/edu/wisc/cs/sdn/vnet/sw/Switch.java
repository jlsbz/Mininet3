package edu.wisc.cs.sdn.vnet.sw;

import java.util.*;
import net.floodlightcontroller.packet.Ethernet;
import net.floodlightcontroller.packet.MACAddress;
import edu.wisc.cs.sdn.vnet.Device;
import edu.wisc.cs.sdn.vnet.DumpFile;
import edu.wisc.cs.sdn.vnet.Iface;

/**
 * @author Aaron Gember-Jacobson
 */
public class Switch extends Device
{	
  private class Entry
  {
    public Iface iface;
    public long time;
    
    public Entry(Iface iface, long time)
    {
      this.iface = iface;
      this.time = time;
    }
    
    public String toString()
    {
      return iface.getName() + " " + String.valueOf(time);
    }
  }
  
  private Hashtable<MACAddress, Entry> switchTable = new Hashtable();
  
	/**
	 * Creates a router for a specific host.
	 * @param host hostname for the router
	 */
	public Switch(String host, DumpFile logfile)
	{
		super(host,logfile);
	}

	/**
	 * Handle an Ethernet packet received on a specific interface.
	 * @param etherPacket the Ethernet packet that was received
	 * @param inIface the interface on which the packet was received
	 */
	public void handlePacket(Ethernet etherPacket, Iface inIface)
	{
		System.out.println("*** -> Received packet: " +
                etherPacket.toString().replace("\n", "\n\t"));

		/********************************************************************/
		/* TODO: Handle packets                                             */
		
		long now = System.currentTimeMillis();
		MACAddress sourceMac = etherPacket.getSourceMAC();
		MACAddress destMac = etherPacket.getDestinationMAC();
		switchTable.put(sourceMac, new Entry(inIface, now));
		
		System.out.println(switchTable.toString());
		
		Entry entry = switchTable.get(destMac);
		if (entry != null && now - entry.time <= 15 * 1000)
	    sendPacket(etherPacket, entry.iface);
	  else 
	    for (Iface outIface : super.interfaces.values())
	      if (!outIface.getName().equals(inIface.getName()))
	        sendPacket(etherPacket, outIface);
		
		/********************************************************************/
	}
}
