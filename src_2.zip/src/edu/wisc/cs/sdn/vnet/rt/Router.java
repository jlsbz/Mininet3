package edu.wisc.cs.sdn.vnet.rt;

import java.util.*;
import java.nio.ByteBuffer;

import edu.wisc.cs.sdn.vnet.Device;
import edu.wisc.cs.sdn.vnet.DumpFile;
import edu.wisc.cs.sdn.vnet.Iface;

import net.floodlightcontroller.packet.*;


/**
 * @author Aaron Gember-Jacobson and Anubhavnidhi Abhashkumar
 */
public class Router extends Device
{	
	/** Routing table for the router */
	private RouteTable routeTable;
	
	/** ARP cache for the router */
	private ArpCache arpCache;
	
	/**
	 * Creates a router for a specific host.
	 * @param host hostname for the router
	 */
	public Router(String host, DumpFile logfile)
	{
		super(host,logfile);
		this.routeTable = new RouteTable();
		this.arpCache = new ArpCache();
	}
	
	/**
	 * @return routing table for the router
	 */
	public RouteTable getRouteTable()
	{ return this.routeTable; }
	
	/**
	 * Load a new routing table from a file.
	 * @param routeTableFile the name of the file containing the routing table
	 */
	public void loadRouteTable(String routeTableFile)
	{
		if (!routeTable.load(routeTableFile, this))
		{
			System.err.println("Error setting up routing table from file "
					+ routeTableFile);
			System.exit(1);
		}
		
		System.out.println("Loaded static route table");
		System.out.println("-------------------------------------------------");
		System.out.print(this.routeTable.toString());
		System.out.println("-------------------------------------------------");
	}
	
	/**
	 * Load a new ARP cache from a file.
	 * @param arpCacheFile the name of the file containing the ARP cache
	 */
	public void loadArpCache(String arpCacheFile)
	{
		if (!arpCache.load(arpCacheFile))
		{
			System.err.println("Error setting up ARP cache from file "
					+ arpCacheFile);
			System.exit(1);
		}
		
		System.out.println("Loaded static ARP cache");
		System.out.println("----------------------------------");
		System.out.print(this.arpCache.toString());
		System.out.println("----------------------------------");
	}

  private short computeChecksum(IPv4 header)
  {
    byte[] data = new byte[header.getHeaderLength() * 4];
    ByteBuffer bb = ByteBuffer.wrap(data);

    bb.put((byte) (((header.getVersion() & 0xf) << 4) | (header.getHeaderLength() & 0xf)));
    bb.put(header.getDiffServ());
    bb.putShort(header.getTotalLength());
    bb.putShort(header.getIdentification());
    bb.putShort((short) (((header.getFlags() & 0x7) << 13) | (header.getFragmentOffset() & 0x1fff)));
    bb.put(header.getTtl());
    bb.put(header.getProtocol());
    bb.putShort(header.getChecksum());
    bb.putInt(header.getSourceAddress());
    bb.putInt(header.getDestinationAddress());
    if (header.getOptions() != null)
      bb.put(header.getOptions());

    bb.rewind();
    int accumulation = 0;
    for (int i = 0; i < header.getHeaderLength() * 2; ++i) {
        accumulation += 0xffff & bb.getShort();
    }
    accumulation = ((accumulation >> 16) & 0xffff)
            + (accumulation & 0xffff);
    return (short) (~accumulation & 0xffff);
  }
  
	/**
	 * Handle an Ethernet packet received on a specific interface.
	 * @param etherPacket the Ethernet packet that was received
	 * @param inIface the interface on which the packet was received
	 */
	public void handlePacket(Ethernet etherPacket, Iface inIface)
	{
		System.out.println("*** -> Received packet: " +
                etherPacket.toString().replace("\n", "\n\t"));
		
		/********************************************************************/
		/* TODO: Handle packets                                             */
		
		if (etherPacket.getEtherType() != Ethernet.TYPE_IPv4)
    {
      System.out.println("IPv4 only");
      return;
    }
	  
	  IPv4 header = (IPv4) etherPacket.getPayload();
	  
	  short checksum = computeChecksum(header);
	  if ((checksum & 0xffff) != 0x0000)
	  {
	    System.out.println("Packet Corrupted");
	    return;
	  }
	  
	  byte ttl = header.getTtl();
	  if (--ttl == 0)
	  {
	    System.out.println("Go die");
	    return;
	  }
		
		int destIP = header.getDestinationAddress();
		for (Iface iface : super.interfaces.values())
		  if (destIP == iface.getIpAddress())
		  {
		    System.out.println("Ip matches interface");
		    return;
		  }
		
		RouteEntry routeEntry = routeTable.lookup(destIP);
		if (routeEntry == null)
		{
		  System.out.println("Dest IP Error");
		  return;
		}
		
		header.setTtl(ttl);
		header.resetChecksum();
		header.setChecksum(computeChecksum(header));
		int nextHopIP = routeEntry.getGatewayAddress() != 0 ? routeEntry.getGatewayAddress() : destIP;
		etherPacket.setSourceMACAddress(routeEntry.getInterface().getMacAddress().toBytes());
		etherPacket.setDestinationMACAddress(arpCache.lookup(nextHopIP).getMac().toBytes());

    System.out.println("Send etherPacket : " + etherPacket.toString().replace("\n", "\n\t"));
    sendPacket(etherPacket, routeEntry.getInterface());
    
		/********************************************************************/
	}
}
